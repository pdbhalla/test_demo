// JavaScript Document


$(document).ready(function(){
	$(".navbar ul li a").click(function(e){
		e.preventDefault();
		var href_value=this.hash;
		$("html").animate({
			scrollTop:$(href_value).offset().top
			
		},500,function(){
		
			window.location.hash=href_value;
			
		});
		
		
		
		
	});
	
});


$(document).ready(function(){
	$("#custom-date").datepicker({
		
		dateFormat:"dd/mm/yy",
		showAnim:"slide",
		duration:5000
	}
	);
}



);

<!--retrive file name in upload button-->
	
$(document).ready(function(){
	
	$("#upload").on("change", function(){
		var file_name=this.files[0].name;
		$(".custom-file-label").html(file_name);
	});
}




);




<!-- trigered upload function-->
$(document).ready(function(){
	
	$("#upload-active").click(function(){
		var input=document.createElement("INPUT");
		input.type="file";
		input.accept="images/*";
		input.click();
		input.onchange=function(){
		var file_name=this.files[0].name;
		$("#upload").attr("placeholder",file_name);	
		}
	});
});	
	

