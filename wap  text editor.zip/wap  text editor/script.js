function wap(){
	var x=document.getElementById("edit").value;
	var y=document.getElementById("result");
	y.innerHTML=x;
}