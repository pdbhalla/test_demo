//display purchase account

function display_purchase_ac()
{
	var input = document.getElementById("purchase-input");
	var i,j;
	input.onclick = function(){
		document.getElementById("purchase-hint").innerHTML = "";
		for(i=0;i<localStorage.length;i++)
		{
			var all_keys = localStorage.key(i);
			if(all_keys.match("ledger_no"))
			{
				var key_data = localStorage.getItem(all_keys);
				var main_data = JSON.parse(key_data);
				if(main_data.group.match("Purchase Account"))
				{
					var hint = document.getElementById("purchase-hint");
					hint.style.display = "block";
					hint.innerHTML += "<p class='hint-hover'>"+main_data.ledger_name+"</p>";
					var hint_hover = document.getElementsByClassName("hint-hover");
					for(j=0;j<hint_hover.length;j++)
					{
						hint_hover[j].onmouseover = function(){
							this.style.background = "blue";
							this.style.color = "white";
							this.onclick = function(){
								input.value = this.innerHTML;
								document.getElementById("add-item").disabled = false;
								input.focus();
								hint.style.display = "none";
							}
						}

						hint_hover[j].onmouseout = function(){
							this.style.background = "";
							this.style.color = "";
						}
					}
				}
			}
		}
	}
	input.oninput = function(){
		var hint_hover = document.getElementsByClassName("hint-hover");
		for(i=0;i<hint_hover.length;i++)
		{
			if(hint_hover[i].innerHTML.toUpperCase().match(input.value.toUpperCase()) != null)
			{
				hint_hover[i].style.display = "block";
			}
			else{
				hint_hover[i].style.display = "none";
			}
		}
	}
	input.click();
	input.focus();

	//enter on purchase input

	input.onkeyup = function(event){
		if(event.keyCode == 13)
		{
			if(this.value != "")
			{
				var hint_hover = document.getElementsByClassName("hint-hover");
				for(i=0;i<hint_hover.length;i++)
				{
					if(this.value.toUpperCase() == hint_hover[i].innerHTML.toUpperCase())
						{
							document.getElementById("add-item").disabled = false;
							add_item();
							move_to_supplier();
							document.getElementById("purchase-hint").style.display = "none";
						}
				}
			}
		}
	}

}

display_purchase_ac();

//add item

function add_item(){
	var item_table = document.getElementById("item-table");
	var tr = document.createElement("TR");
	item_table.append(tr);
	var td_item = document.createElement("TD");
	var td_qty = document.createElement("TD");
	var td_rate = document.createElement("TD");
	var td_sp = document.createElement("TD");
	var td_per = document.createElement("TD");
	var td_amount = document.createElement("TD");
	var td_delete = document.createElement("TD");
	tr.append(td_item);
	tr.append(td_qty);
	tr.append(td_rate);
	tr.append(td_sp);
	tr.append(td_per);
	tr.append(td_amount);
	tr.append(td_delete);
	var item_input = document.createElement("INPUT");
	item_input.type="text";
	item_input.id = "item-input";
	item_input.className = "item-input";
	item_input.placeholder = "Laptop";
	var qty_input = document.createElement("INPUT");
	qty_input.type="number";
	qty_input.id = "qty-input";
	qty_input.className = "qty-input";
	qty_input.placeholder = "00.00";
	qty_input.disabled = true;
	var rate_input = document.createElement("INPUT");
	rate_input.type="number";
	rate_input.id = "rate-input";
	rate_input.className = "rate-input";
	rate_input.placeholder = "00.00";
	rate_input.disabled = true;
	var sp_input = document.createElement("INPUT");
	sp_input.type="number";
	sp_input.id = "sp-input";
	sp_input.className = "sp-input";
	sp_input.placeholder = "00.00";
	sp_input.disabled = true;
	var per_input = document.createElement("SELECT");
	var default_option = document.createElement("OPTION");
	default_option.append(document.createTextNode("Unit ?"));
	per_input.append(default_option);
	per_input.id = "per-input";
	per_input.className = "per-input";
	var i;
	for(i=0;i<localStorage.length;i++)
	{
		var all_keys = localStorage.key(i);
		if(all_keys.match("unit_of_measure"))
		{
			var key_data = localStorage.getItem(all_keys);
			var data = JSON.parse(key_data);
			var option = document.createElement("OPTION");
			option.append(document.createTextNode(data.symbol));
			per_input.append(option);
		}
	}
	var amount_input = document.createElement("INPUT");
	amount_input.type="number";
	amount_input.id = "amount-input";
	amount_input.className = "amount-input";
	amount_input.placeholder = "00.00";
	amount_input.disabled = true;
	var delete_icon = document.createElement("I");
	delete_icon.id = "delete-icon";
	delete_icon.className = "fa fa-trash";
	td_item.append(item_input);
	td_qty.append(qty_input);
	td_rate.append(rate_input);
	td_sp.append(sp_input);
	td_per.append(per_input);
	td_amount.append(amount_input);
	td_delete.append(delete_icon);
	td_delete.align = "center";

	//delete item

	delete_icon.onclick = function(){
		var del_element = this.parentElement.parentElement;
		del_element.remove();
		subtotal();
		calculate_taxes();
		calculate_total();
		if(item_table.getElementsByTagName("TR").length == 1)
		{
			document.getElementById("subtotal-amount").innerHTML = " 00.00";
			var taxes_amount = document.getElementById("taxes-amount");
			var p = taxes_amount.getElementsByTagName("P");
			for(i=0;i<p.length;i++)
			{
				p[i].innerHTML = " 00.00";
			}
			document.getElementById("calculated-total").innerHTML = " 00.00";
			document.getElementById("paid").value = "";
			document.getElementById("calculated-dues").innerHTML = " 00.00";
		}
	}

	//enabling input field

	item_input.oninput = function(){
		qty_input.disabled = false;
		qty_input.oninput = function(){
			amount_input.value = (qty_input.value*rate_input.value).toFixed(2);
			subtotal();
			calculate_taxes();
			calculate_total();
			rate_input.disabled = false;
			rate_input.onkeyup = function(event){
				sp_input.disabled =false;
				var key = String.fromCharCode(event.keyCode);
				var per_value = per_input.getElementsByTagName("OPTION");
				for(i=0;i<per_value.length;i++)
				{
					if(per_value[i].value.toUpperCase().charAt(0).match(key.toUpperCase()))
					{
						per_input.value = per_input[i].value;
					}
				}
				amount_input.disabled = false;
				amount_input.value = (qty_input.value*rate_input.value).toFixed(2);
				subtotal();
				calculate_taxes();
				calculate_total();
				amount_input.onkeydown = function(){
					return false;
				}
				amount_input.oncontextmenu = function(){
					return false;
				}
			}
		}
	}

	//active item field

	var active_item = document.getElementsByClassName("item-input");
	active_item[active_item.length-1].focus();

	//on enter coding

	item_input.onkeyup = function(){
		if(event.keyCode == 13)
		{
			qty_input.focus();
		}
	}

	qty_input.onkeyup = function(){
		if(event.keyCode == 13)
		{
			rate_input.focus();
		}
	}

	rate_input.onkeydown = function(event){

		if(event.keyCode == 13)
		{
			sp_input.focus();
		}
	} 

	sp_input.onkeydown = function(event){
		if(event.keyCode == 13)
		{
			per_input.focus();
			per_input.onchange = function(){
				var tr_unit = this.parentElement.parentElement;
				var all_input = tr_unit.getElementsByTagName("INPUT");
				var cost_price = Number(all_input[2].value);
				var sell_price = Number(all_input[3].value);
				var max_num = Math.max(cost_price,sell_price);
				if(max_num == sell_price)
				{
					add_item();
				}

				else{
					alert("Selling price should be higher than cost price");
					per_input.value = "Unit ?"
					all_input[3].focus();
					all_input[3].style.border = "1px solid red";
					all_input[3].oninput = function(){
						this.style.border = "";
					}
				}
			}
		}
	}


}


function call_add_item()
{
	var add_btn = document.getElementById("add-item");
	add_btn.onclick = function(){
		add_item();
		move_to_supplier();
	}

	document.onkeyup = function(event)
	{
		if(event.altKey && event.keyCode == 65)
		{
			add_item();
			move_to_supplier();
		}
	}
}

call_add_item();

function subtotal(){
	var all_amount = document.getElementsByClassName("amount-input");
	var i,previous_data = 0;
	for(i=0;i<all_amount.length;i++)
	{
		previous_data += Number(all_amount[i].value);
		document.getElementById("subtotal").innerHTML = "<p id='subtotal-amount' class='fa fa-rupee'> "+previous_data.toFixed(2)+"</p>";
	}
}

// set tax

function set_tax(){
	var tax_name = document.getElementById("tax-name");
	var tax = document.getElementById("tax");
	tax_name.onchange = function(){
		if(this.value.match(" tax") != null)
		{
			tax.oninput = function(){
			if(tax.value.charAt(0).indexOf("%") == -1)
			{
				document.getElementById("tax-form").onsubmit = function(){
					if(tax.value.indexOf("%") != -1)
					{
						var regexp = /[a-z!=@#+$_^&*({;:"'|\]?/<,>})-]/i;
						var check = tax.value.match(regexp);
						if(check == null)
						{
							var tax_data = {
								tax_name:tax_name.value,
								tax:tax.value
							};

							var store_tax = JSON.stringify(tax_data);
							localStorage.setItem("ptax_"+tax_name.value,store_tax);
							if(localStorage.getItem("ptax_"+tax_name.value,store_tax) != null)
							{
								var notice = document.getElementById("notice");
								notice.innerHTML = "Success";
								notice.style.color = "red";
								document.getElementById("taxes-name").innerHTML = "";
								read_tax();
								calculate_taxes();
								setTimeout(function(){
									notice.innerHTML = "Tax Setup";
									notice.style.color = "black";
									document.getElementById("tax-form").reset();
								},2000);
								return false;
							}
						}
						else{
							alert("Only 0 to 9 and % symbol are allowed");
							return false;
						}
					}
					else{
						alert("must use % symbol after tax amount");
					}
				}
			}
			else{
				alert("Don't use % symbol in first place");
			}
		}
		}

		else{
			alert("Must add tax word or add space before tax word");
		}
	} 
}

set_tax();

//read taxes from localStorage

function read_tax(){
	var i;
	for(i=0;i<localStorage.length;i++)
	{
		var all_keys = localStorage.key(i);
		if(all_keys.match("ptax_"))
		{
			var key_data = localStorage.getItem(all_keys);
			var read_data = JSON.parse(key_data);
			document.getElementById("taxes-name").innerHTML += "<p style='padding:0;margin:0;'>"+read_data.tax_name+" - "+"<span>"+read_data.tax+"</span>"+"</p><br>";
		}
	}
}

read_tax();

//calculate taxes 

function calculate_taxes(){
	var subtotal_amount = Number(document.getElementById("subtotal-amount").innerHTML);
	var taxes_name = document.getElementById("taxes-name");
	var span = taxes_name.getElementsByTagName("SPAN");
	document.getElementById("taxes-amount").innerHTML = "";
	var i;
	for(i=0;i<span.length;i++)
	{
		var num = span[i].innerHTML.replace("%","");
		var cal = (subtotal_amount*num)/100;
		var tofixed = cal.toFixed(2);
		var percentage = "<p class='fa fa-rupee' style='padding:0;margin:0;'> "+tofixed+"</p><br><br>";
		document.getElementById("taxes-amount").innerHTML += percentage;
	}
}

//show default taxes amount

function default_taxes_amount(){
	var taxes_amount = document.getElementById("taxes-amount");
	var i;
	for(i=0;i<localStorage.length;i++)
	{
		var all_keys = localStorage.key(i);
		if(all_keys.match("ptax_"))
		{
			var p = document.createElement("P");
			p.append(document.createTextNode(" 00.00"));
			p.style.margin = "0";
			p.style.padding = "0";
			p.innerHTML += "<br><br>"; 
			taxes_amount.append(p);
			
		}
	}
}

default_taxes_amount();

//calculate total

function calculate_total()
{	
	var subtotal_amount = Number(document.getElementById("subtotal-amount").innerHTML);
	var taxes_name = document.getElementById("taxes-name").innerHTML;
	if(taxes_name != "")
	{
		var taxes_amount = document.getElementById("taxes-amount");
		var p = taxes_amount.getElementsByTagName("P");
		var i;
		for(i=0;i<p.length;i++)
		{
			subtotal_amount += Number(p[i].innerHTML);
			document.getElementById("total").innerHTML = "<p class='fa fa-rupee' id='calculated-total'> "+subtotal_amount.toFixed(2)+"</p>";
		}
		paid();
	}

	else{
		document.getElementById("total").innerHTML = "<p class='fa fa-rupee' id='calculated-total'> "+subtotal_amount.toFixed(2)+"</p>";
		paid();
	}
}

//calculate paid and dues

function paid()
{
	var paid = document.getElementById("paid");
	paid.oninput = function(){
		var total = Number(document.getElementById("calculated-total").innerHTML);
		var dues = document.getElementById("dues");
		dues.innerHTML = "<p id='calculated-dues' class='fa fa-rupee'> "+(total-Number(this.value)).toFixed(2)+"</p>";
	}
}


//arrow down and arrow up on purchase account

function arrow_down()
{
	var i;
	var p = document.getElementsByClassName("hint-hover");
	var input = document.getElementById("purchase-input");
	input.onkeydown = function(event){
		if(event.keyCode == 40)
		{
			if(sessionStorage.getItem("count") == null)
			{
				p[0].style.backgroundColor = "blue";
				p[0].style.color = "white";
				this.value = p[0].innerHTML;
				sessionStorage.setItem("count",0);	
			}

			else{
				for(i=0;i<p.length;i++)
				{
					p[i].style.backgroundColor = "inherit";
					p[i].style.color = "inherit";
				}
				var current = Number(sessionStorage.getItem("count"))+1;
				if(p[current] != undefined)
				{
					p[current].style.backgroundColor = "blue";
					p[current].style.color = "white";
					this.value = p[current].innerHTML;
					sessionStorage.setItem("count",current);
				}

				else{
					sessionStorage.setItem("count",0);	
					p[0].style.backgroundColor = "blue";
					p[0].style.color = "white";
					this.value = p[0].innerHTML;
				}
			}
		}

		else if(event.keyCode == 13)
		{
			sessionStorage.removeItem("count");
			document.getElementById("purchase-hint").style.display = "none";
			document.getElementById("add-item").disabled = false;
			add_item();
			move_to_supplier();
		}

	}

		input.onkeyup = function(event){
		if(event.keyCode == 38)
		{
			if(sessionStorage.getItem("count") == null)
			{
				p[p.length-1].style.backgroundColor = "blue";
				p[p.length-1].style.color = "white";
				this.value = p[p.length-1].innerHTML;
				sessionStorage.setItem("count",p.length-1);	
			}

			else{
				for(i=0;i<p.length;i++)
				{
					p[i].style.backgroundColor = "inherit";
					p[i].style.color = "inherit";
				}
				var current = Number(sessionStorage.getItem("count"))-1;
				if(p[current] != undefined)
				{
					p[current].style.backgroundColor = "blue";
					p[current].style.color = "white";
					this.value = p[current].innerHTML;
					sessionStorage.setItem("count",current);
				}

				else{
					sessionStorage.setItem("count",0);	
					p[p.length-1].style.backgroundColor = "blue";
					p[p.length-1].style.color = "white";
					this.value = p[p.length-1].innerHTML;
				}
			}
		}

		else if(event.keyCode == 13)
		{
			sessionStorage.removeItem("count");
			document.getElementById("purchase-hint").style.display = "none";
			document.getElementById("add-item").disabled = false;
			add_item();
			move_to_supplier();
		}

	}
}

arrow_down();

//purchase date

function purchase_date()
{
	var date = document.getElementById("purchase-date");
	var d = new Date();
	var c_date = d.getDate();
	var c_month = d.getMonth()+1;
	var c_year = d.getFullYear();
	date.innerHTML = "<span id='p-date'>"+c_date+"-"+c_month+"-"+c_year+"</span>";
	var p_date = document.getElementById("p-date");
	p_date.style.cursor = "pointer";
	p_date.title = "Click to change";
	p_date.onclick = function()
	{
		this.innerHTML = "";
		var input = document.createElement("INPUT");
		input.type = "date";
		date.append(input);
		input.onblur = function(){
			this.remove();
			var s_date = new Date(this.value);
			var final_date = [s_date.getDate(),s_date.getMonth()+1,s_date.getFullYear()];
			p_date.innerHTML = final_date[0]+"-"+final_date[1]+"-"+final_date[2];
		}

		input.onchange = function(){
			this.remove();
			var s_date = new Date(this.value);
			var final_date = [s_date.getDate(),s_date.getMonth()+1,s_date.getFullYear()];
			p_date.innerHTML = final_date[0]+"-"+final_date[1]+"-"+final_date[2];
		}
	}
}
purchase_date();

//storing voucher

function store_voucher()
{
	var i,store_item = [],store_qty = [],store_rate = [],store_sp = [],store_per = [],store_amount = [],store_tax = [];
	var voucher_no = document.getElementById("voucher-no").innerHTML;
	var voucher_date = document.getElementById("p-date").innerHTML;
	var ac_name = document.getElementById("purchase-input").value;
	var item_input = document.getElementsByClassName("item-input");
	for(i=0;i<item_input.length;i++)
	{
		store_item[i] = item_input[i].value;
	}

	var qty_input = document.getElementsByClassName("qty-input");
	for(i=0;i<qty_input.length;i++)
	{
		store_qty[i] = qty_input[i].value;
	}

	var rate_input = document.getElementsByClassName("rate-input");
	for(i=0;i<rate_input.length;i++)
	{
		store_rate[i] = rate_input[i].value;
	}

	var sp_input = document.getElementsByClassName("sp-input");
	for(i=0;i<sp_input.length;i++)
	{
		store_sp[i] = sp_input[i].value;
	}

	var per_input = document.getElementsByClassName("per-input");
	for(i=0;i<per_input.length;i++)
	{
		store_per[i] = per_input[i].value;
	}

	var amount_input = document.getElementsByClassName("amount-input");
	for(i=0;i<amount_input.length;i++)
	{
		store_amount[i] = amount_input[i].value;
	}

	var s_name = document.getElementById("supplier-name").value;
	var s_mob = document.getElementById("supplier-mobile").value;
	var s_address = document.getElementById("supplier-address").value;
	var subtotal = document.getElementById("subtotal-amount").innerHTML;
	var taxes_amount = document.getElementById("taxes-amount");
	var taxes = taxes_amount.getElementsByTagName("P");

	for(i=0;i<taxes.length;i++)
	{
		store_tax[i] = taxes[i].innerHTML;
	}

	var total = document.getElementById("calculated-total").innerHTML;
	var paid = document.getElementById("paid").value;
	var dues = document.getElementById("calculated-dues").innerHTML;

	var purchase_details = {
		voucher_no : voucher_no,
		voucher_date : voucher_date,
		ac_name :ac_name,
		store_item : store_item,
		store_qty : store_qty,
		store_rate : store_rate,
		store_sp : store_sp,
		store_per : store_per,
		store_amount : store_amount,
		s_name : s_name,
		s_mob : s_mob,
		s_address : s_address,
		subtotal : subtotal,
		store_tax : store_tax,
		total : total,
		paid : paid,
		dues : dues
	}
	var purchase_data = JSON.stringify(purchase_details);
	localStorage.setItem("purchase_voucher_"+voucher_no,purchase_data);
	if(localStorage.getItem("purchase_voucher_"+voucher_no) != null)
	{
		var notice = document.getElementById("success-notice");
		notice.innerHTML = "Saving please wait...";
		setTimeout(function(){
			notice.innerHTML = "<span style='color:red;font-family:Ubuntu;font-size:20px;font-width:bold;'>Click here to print voucher || ctrl+r to create new voucher</span>"
		},1000);
	}

	else{
		alert("Voucher not saved press ok to create again");
		window.location = location.href;
	}
}

function store_now(){
	document.getElementById("store").onclick = function(){
		if(document.getElementById("subtotal-amount") != null)
		{
			if(document.getElementById("paid").value != "")
			{
				store_voucher();
			}

			else{
				alert("paid is empty");
				document.getElementById("paid").focus();
				return false;
			}
		}

		else{
			alert("no item bought yet !");
			return false;
		}	
	}
}

store_now();

//move to supplier

function move_to_supplier()
{
	var s_name = document.getElementById("supplier-name");
	var s_mob = document.getElementById("supplier-mobile");
	var s_address = document.getElementById("supplier-address");
	document.onkeyup = function(event){
		if(event.shiftKey && event.keyCode == 83)
		{
			if(document.getElementById("subtotal-amount") != null)
			{
				s_name.focus();
				s_name.style.boxShadow = "0px 0px 10px blue";
				s_name.style.borderColor = "blue";
			}

			else{
				alert("No item bought yet");
			}
		}
	}

	s_name.onkeyup = function(event){
		if(event.keyCode == 13)
		{
			s_mob.focus();
			s_name.style.boxShadow = "";
			s_name.style.borderColor = "";
		}
	}

	s_mob.onkeyup = function(event){
		if(event.keyCode == 13)
		{
			s_address.focus();		
		}
	}
}


//voucher no

function voucher_no(){
	var voucher_no = document.getElementById("voucher-no");
	var i,large_no = 0;
	for(i=0;i<localStorage.length;i++)
	{
		var all_keys = localStorage.key(i);
		if(all_keys.match("purchase_voucher"))
		{
			var num = Number(all_keys.replace("purchase_voucher_",""));
			if(num > large_no)
			{
				large_no = num;
			}
		}
	}
	voucher_no.innerHTML = large_no+1;
}

voucher_no();

//current balance

function current_balance()
{
	var i,balance = 0;
	for(i=0;i<localStorage.length;i++)
	{
		var all_keys = localStorage.key(i);
		if(all_keys.match("purchase_voucher"))
		{
			var key_data = localStorage.getItem(all_keys);
			var data = JSON.parse(key_data);
			balance += Number(data.total);
		}

	}
	document.getElementById("c-balance").innerHTML = balance+" Cr";
}

current_balance();

//show company logo and name

function show_cmp_details()
{
	var logo = localStorage.getItem("company-logo");
	var img = document.getElementById("cmp-logo");
	img.src = logo;
	var cmp = localStorage.getItem("company");
	var company = JSON.parse(cmp);
	var address = document.getElementById("address");
	address.innerHTML = "Venue : "+company.address+"<br>Phone : "+company.phone;
}

show_cmp_details();

//shortcut toggle

function shortcut_toggle()
{
	var short_icon = document.getElementById("short-icon");
	var short_toggle = document.getElementById("short-toggle");
	short_icon.onclick = function(){
		if(short_toggle.offsetHeight == 0)
		{
			short_toggle.style.height = "220px";
			short_toggle.style.webkitTransition = "1s";
			short_toggle.style.transition = "1s";
			setTimeout(function(){short_icon.className = "fa fa-toggle-down";},1000)
		}

		else{
			short_toggle.style.height = "0";
			short_toggle.style.webkitTransition = "1s";
			short_toggle.style.transition = "1s";
			setTimeout(function(){short_icon.className = "fa fa-toggle-up";},1000)
		}
	}
}

shortcut_toggle();

//search voucher

function search_voucher()
{
	var search = document.getElementById("search");
	search.onkeyup = function(event){
		if(event.keyCode == 13)
		{
			if(this.value != "")
			{
				var voucher = localStorage.getItem("purchase_voucher_"+this.value);
				if(voucher != null)
				{
					delete_voucher();
					var data = JSON.parse(voucher);
					document.getElementById("voucher-no").innerHTML = data.voucher_no;
					document.getElementById("p-date").innerHTML = data.voucher_date;
					document.getElementById("purchase-input").value = data.ac_name;
					document.getElementById("purchase-hint").style.display = "none";
					var i;
					for(i=0;i<data.store_item.length;i++)
					{
						add_item();
					}

					var item_input = document.getElementsByClassName("item-input");
					var qty_input = document.getElementsByClassName("qty-input");
					var rate_input = document.getElementsByClassName("rate-input");
					var sp_input = document.getElementsByClassName("sp-input");
					var per_input = document.getElementsByClassName("per-input");
					var amount_input = document.getElementsByClassName("amount-input");
					for(i=0;i<item_input.length;i++)
					{
						item_input[i].value = data.store_item[i];
						qty_input[i].value = data.store_qty[i];
						qty_input[i].disabled = false;
						rate_input[i].value = data.store_rate[i];
						rate_input[i].disabled = false;
						sp_input[i].value = data.store_sp[i];
						sp_input[i].disabled = false;
						per_input[i].value = data.store_per[i];
						amount_input[i].value = data.store_amount[i];
						amount_input[i].disabled = false;

					}

					document.getElementById("supplier-name").value = data.s_name;
					document.getElementById("supplier-mobile").value = data.s_mob;
					document.getElementById("supplier-address").value = data.s_address;
					var subtotal_td = document.getElementById("subtotal");
					subtotal_td.innerHTML = "";
					var subtotal_p = document.createElement("P");
					subtotal_p.append(document.createTextNode(data.subtotal));
					subtotal_p.id = "subtotal-amount";
					subtotal_p.className = "fa fa-rupee";
					subtotal_td.append(subtotal_p);
					document.getElementById("taxes-amount").innerHTML = "";
					for(i=0;i<data.store_tax.length;i++)
					{
						var taxes_amount = document.getElementById("taxes-amount");
						var taxes_p = document.createElement("P");
						var taxes_br = document.createElement("BR");
						taxes_p.append(document.createTextNode(" "+data.store_tax[i]));
						taxes_p.className = "fa fa-rupee";
						taxes_p.style.float = "left";
						taxes_p.style.clear = "left";
						taxes_p.style.margin = "2px";
						taxes_p.style.padding = "0";
						taxes_p.innerHTML += "<br><br>";
						//taxes_p.append(document.createElement("BR"));
						
						taxes_amount.append(taxes_p);
					}

					var total = document.getElementById("total");
					total.innerHTML = "";
					var total_p = document.createElement("P");
					total_p.append(document.createTextNode(data.total));
					total_p.id = "calculated-total";
					total_p.className = "fa fa-rupee";
					total.append(total_p);

					document.getElementById("paid").value = data.paid;

					var dues = document.getElementById("dues");
					dues.innerHTML = "";
					var dues_p = document.createElement("P");
					dues_p.append(document.createTextNode(data.dues));
					dues_p.id = "calculated-dues";
					dues_p.className = "fa fa-rupee";
					dues.append(dues_p);
				}

				else{
					alert("No voucher found !");
				}
			}

			else{
				alert("Enter voucher number");
			}
		}
	}
}

search_voucher();

//delete voucher

function delete_voucher()
{
	var del = document.getElementById("voucher-delete");
	del.onclick = function(){
		var choice = window.confirm("Do you want to delete voucher");
		if(choice == true)
		{
			localStorage.removeItem("purchase_voucher_"+document.getElementById("search").value);
			window.location = location.href;
		}
	}
}