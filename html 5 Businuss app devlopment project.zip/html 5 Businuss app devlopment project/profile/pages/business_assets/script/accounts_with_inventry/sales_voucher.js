// company name and profile picture

function cmp_name()
{
	var cmp_name = document.getElementById("sale-cmp-name");
	var cmp_logo = document.getElementById("sale-cmp-logo");
	var cmp_address = document.getElementById("sale-address");
	var key_data = localStorage.getItem("company");
	var data = JSON.parse(key_data);
	cmp_name.innerHTML = data.cmp_name;
	cmp_address.innerHTML = "Venue : "+data.address+"<br>Phone : "+data.phone;
	var logo = localStorage.getItem("company-logo");
	cmp_logo.src = logo;
}
cmp_name();

//sale a/c name

function sales_ac_name()
{
	var sales_input = document.getElementById("sales-input");
	var sales_hint = document.getElementById("sales-hint");
	var i;
	for(i=0;i<localStorage.length;i++)
	{
		var all_keys = localStorage.key(i);
		if(all_keys.match("ledger_no"))
		{
			var key_data = localStorage.getItem(all_keys);
			var data = JSON.parse(key_data);
			if(data.group == "Sales Account")
			{
				var p = document.createElement("P");
				p.style.padding = "5px";
				p.className = "sale-hint-hover";
				p.append(document.createTextNode(data.ledger_name));
				sales_hint.append(p);
				p.onmouseover = function(){
					this.style.backgroundColor = "blue";
					this.style.color = "white";
					this.onclick = function(){
						sales_input.value = this.innerHTML;
						sales_hint.style.display = "none";
						sales_input.onclick = function(){
							sales_hint.style.display = "block";
						}
					}

				}

				p.onmouseout = function(){
					this.style.backgroundColor = "";
					this.style.color = "";
				}
			}
		}
	}
}

sales_ac_name();

//arrow down and arrow up on sale account

function arrow_down()
{
	var i;
	var p = document.getElementsByClassName("sale-hint-hover");
	var input = document.getElementById("sales-input");
	input.onkeydown = function(event){
		if(event.keyCode == 40)
		{
			if(sessionStorage.getItem("count") == null)
			{
				p[0].style.backgroundColor = "blue";
				p[0].style.color = "white";
				this.value = p[0].innerHTML;
				sessionStorage.setItem("count",0);	
			}

			else{
				for(i=0;i<p.length;i++)
				{
					p[i].style.backgroundColor = "inherit";
					p[i].style.color = "inherit";
				}
				var current = Number(sessionStorage.getItem("count"))+1;
				if(p[current] != undefined)
				{
					p[current].style.backgroundColor = "blue";
					p[current].style.color = "white";
					this.value = p[current].innerHTML;
					sessionStorage.setItem("count",current);
				}

				else{
					sessionStorage.setItem("count",0);	
					p[0].style.backgroundColor = "blue";
					p[0].style.color = "white";
					this.value = p[0].innerHTML;
				}
			}
		}

		else if(event.keyCode == 13)
		{
			sessionStorage.removeItem("count");
			document.getElementById("purchase-hint").style.display = "none";
			document.getElementById("add-item").disabled = false;
			add_item();
			move_to_supplier();
		}

	}

		input.onkeyup = function(event){
		if(event.keyCode == 38)
		{
			if(sessionStorage.getItem("count") == null)
			{
				p[p.length-1].style.backgroundColor = "blue";
				p[p.length-1].style.color = "white";
				this.value = p[p.length-1].innerHTML;
				sessionStorage.setItem("count",p.length-1);	
			}

			else{
				for(i=0;i<p.length;i++)
				{
					p[i].style.backgroundColor = "inherit";
					p[i].style.color = "inherit";
				}
				var current = Number(sessionStorage.getItem("count"))-1;
				if(p[current] != undefined)
				{
					p[current].style.backgroundColor = "blue";
					p[current].style.color = "white";
					this.value = p[current].innerHTML;
					sessionStorage.setItem("count",current);
				}

				else{
					sessionStorage.setItem("count",0);	
					p[p.length-1].style.backgroundColor = "blue";
					p[p.length-1].style.color = "white";
					this.value = p[p.length-1].innerHTML;
				}
			}
		}

		else if(event.keyCode == 13)
		{
			sessionStorage.removeItem("count");
			document.getElementById("purchase-hint").style.display = "none";
			document.getElementById("add-item").disabled = false;
			add_item();
			move_to_supplier();
		}

	}
}

arrow_down();

//add item

function sale_add_item(){
	var item_table = document.getElementById("sale-item-table");
	var tr = document.createElement("TR");
	item_table.append(tr);
	var td_item = document.createElement("TD");
	var td_qty = document.createElement("TD");
	var td_rate = document.createElement("TD");
	var td_per = document.createElement("TD");
	var td_amount = document.createElement("TD");
	var td_delete = document.createElement("TD");
	tr.append(td_item);
	tr.append(td_qty);
	tr.append(td_rate);
	tr.append(td_per);
	tr.append(td_amount);
	tr.append(td_delete);
	var item_input = document.createElement("INPUT");
	item_input.type="text";
	item_input.id = "saleitem-input";
	item_input.className = "saleitem-input";
	item_input.placeholder = "Laptop";
	var qty_input = document.createElement("INPUT");
	qty_input.type="number";
	qty_input.id = "saleqty-input";
	qty_input.className = "saleqty-input";
	qty_input.placeholder = "00.00";
	qty_input.disabled = true;
	var rate_input = document.createElement("INPUT");
	rate_input.type="number";
	rate_input.id = "salerate-input";
	rate_input.className = "salerate-input";
	rate_input.placeholder = "00.00";
	rate_input.disabled = true;
	var per_input = document.createElement("SELECT");
	var default_option = document.createElement("OPTION");
	default_option.append(document.createTextNode("Unit ?"));
	per_input.append(default_option);
	per_input.id = "saleper-input";
	per_input.className = "saleper-input";
	var i;
	for(i=0;i<localStorage.length;i++)
	{
		var all_keys = localStorage.key(i);
		if(all_keys.match("unit_of_measure"))
		{
			var key_data = localStorage.getItem(all_keys);
			var data = JSON.parse(key_data);
			var option = document.createElement("OPTION");
			option.append(document.createTextNode(data.symbol));
			per_input.append(option);
		}
	}
	var amount_input = document.createElement("INPUT");
	amount_input.type="number";
	amount_input.id = "saleamount-input";
	amount_input.className = "saleamount-input";
	amount_input.placeholder = "00.00";
	amount_input.disabled = true;
	var delete_icon = document.createElement("I");
	delete_icon.id = "delete-icon";
	delete_icon.className = "fa fa-trash";
	td_item.append(item_input);
	td_qty.append(qty_input);
	td_rate.append(rate_input);
	td_per.append(per_input);
	td_amount.append(amount_input);
	td_delete.append(delete_icon);
	td_delete.align = "center";

	//delete item

	delete_icon.onclick = function(){
		this.parentElement.parentElement.remove();
	}

	//enable item field

	item_input.oninput = function(){
		qty_input.disabled = false;
	}

	qty_input.oninput = function(){
		rate_input.disabled = false;
		amount_input.value = (qty_input.value*rate_input.value).toFixed(2);
		sale_subtotal();
		sale_calculate_taxes();
		sale_calculate_total();
	}

	rate_input.oninput = function(){
		amount_input.disabled = false;
		amount_input.value = (qty_input.value*rate_input.value).toFixed(2);
		sale_subtotal();
		sale_calculate_taxes();
		sale_calculate_total();
		amount_input.onkeydown = function(){
			return false;
		}
		amount_input.oncontextmenu = function(){
			return false;
		}
	}

	//onenter coding 

	item_input.onkeyup = function(event){
		if(event.keyCode == 13)
		{
			qty_input.focus();
		}
	}

	qty_input.onkeyup = function(event){
		if(event.keyCode == 13)
		{
			rate_input.focus();
		}
	}

	rate_input.onkeydown = function(event){
		if(event.keyCode == 13)
		{
			per_input.focus();
		}
	}

	per_input.onchange = function(){
		sale_add_item();
	}

	//active item field

	var active_item = document.getElementsByClassName("saleitem-input");
	active_item[active_item.length-1].focus();
}

function call_add_item()
{
	document.getElementById("sales-add-item").onclick = function(){
		sale_add_item();
		//show_stocks();
	}
}

call_add_item();

//show stock

function show_stocks()
{
	var saleitem_input = document.getElementsByClassName("saleitem-input");
	var i,j,k,sort_item,show_item = [];
	for(i=0;i<saleitem_input.length;i++)
	{
		saleitem_input[i].onclick = function()
		{
			var stock_hint = document.createElement("DIV");
			stock_hint.id = "stock-hint";
			this.parentElement.style.position = "relative";
			this.parentElement.append(stock_hint);
			this.oninput = function(){
				document.getElementById("stock-hint").innerHTML = "";
				for(i=0;i<localStorage.length;i++){
				var all_keys = localStorage.key(i);
				if(all_keys.match("purchase_voucher"))
				{
					var key_data = localStorage.getItem(all_keys);
					var data = JSON.parse(key_data);
					for(j=0;j<data.store_item.length;j++)
					{
						if(data.store_item[j].toUpperCase().indexOf(this.value.toUpperCase()) != -1)
						{
							for(k=0;k<data.store_item[j].length;k++)
							{
								if(data.store_item[j] != sort_item)
								{
									show_item.push(data.store_item[j]);
									sort_item = data.store_item[j];

								}
							}
						}	
					}
				}
			}	
			for(k=0;k<show_item.length;k++)
			{
				var p = document.createElement("P");
				p.append(document.createTextNode(show_item[k]));
				stock_hint.append(p);
				this.onkeyup = function(event){
				if(event.keyCode == 8)
				{
					if(this.value == "")
					{
						document.getElementById("stock-hint").innerHTML = "";
					}
				}
			}
			}
		}
		}
	}
}

//sales input

var demo, x = [];

function sales_input()
{
	var sales_input = document.getElementById("sales-input");
	var p = document.getElementsByClassName("sale-hint-hover");
	var i;
	sales_input.onkeyup = function(event){
	for(i=0;i<p.length;i++)
	{
		if(p[i].innerHTML.toUpperCase().indexOf(this.value.toUpperCase()) != -1)
		{
			p[i].style.display = "block";
		}
		else{
			p[i].style.display = "none";
		}
	}

	if(event.keyCode == 13)
	{
		for(i=0;i<p.length;i++)
		{
			if(this.value.toUpperCase() == p[i].innerHTML.toUpperCase())
			{
				document.getElementById("sales-hint").style.display = "none";
				var cus_name = document.getElementById("cus-name");
				var cus_number = document.getElementById("cus-number");
				var	cus_address = document.getElementById("cus-address");
				var sales_add_item = document.getElementById("sales-add-item");
				cus_name.disabled = false;
				cus_number.disabled = false;
				cus_address.disabled = false;
				sales_add_item.disabled = false;
				cus_name.focus();
				cus_name.onkeyup = function(event)
				{
					if(event.keyCode == 13)
					{
						cus_number.focus();
					}
				}

				cus_number.onkeyup = function(event)
				{
					if(event.keyCode == 13)
					{
						cus_address.focus();
					}
				}
			}

			else{
				if(this.value.toUpperCase() != demo)
				{
					x.push(this.value.toUpperCase());
					demo = this.value.toUpperCase();
				}
				//alert("sales account not found");
				this.oninput = function(){
					window.location = location.href;
				}

				this.onclick = function(){
					window.location = location.href;
				}
			}
		}
		alert(demo);
	}
}
}

sales_input();

//subtotal

function sale_subtotal(){
	var all_amount = document.getElementsByClassName("saleamount-input");
	var i,previous_data = 0;
	for(i=0;i<all_amount.length;i++)
	{
		previous_data += Number(all_amount[i].value);
		document.getElementById("sale-subtotal").innerHTML = "<p id='salesubtotal-amount' class='fa fa-rupee'>"+previous_data.toFixed(2)+"</p>";
	}
}

// set tax

function sale_set_tax(){
	var tax_name = document.getElementById("sale-tax-name");
	var tax = document.getElementById("sale-tax-amount");
	tax_name.onchange = function(){
		if(this.value.match(" tax") != null)
		{
			tax.oninput = function(){
			if(tax.value.charAt(0).indexOf("%") == -1)
			{
				document.getElementById("sale-tax-form").onsubmit = function(){
					if(tax.value.indexOf("%") != -1)
					{
						var regexp = /[a-z!=@#+$_^&*({;:"'|\]?/<,>})-]/i;
						var check = tax.value.match(regexp);
						if(check == null)
						{
							var tax_data = {
								tax_name:tax_name.value,
								tax:tax.value
							};

							var store_tax = JSON.stringify(tax_data);
							localStorage.setItem("stax_"+tax_name.value,store_tax);
							if(localStorage.getItem("stax_"+tax_name.value,store_tax) != null)
							{
								var notice = document.getElementById("sale-notice");
								notice.innerHTML = "Success";
								notice.style.color = "red";
								document.getElementById("sale-taxes-name").innerHTML = "";
								sale_read_tax();
								sale_calculate_taxes();
								sale_calculate_total();
								setTimeout(function(){
									notice.innerHTML = "Tax Setup";
									notice.style.color = "black";
									document.getElementById("sale-tax-form").reset();
								},2000);
								return false;
							}
						}
						else{
							alert("Only 0 to 9 and % symbol are allowed");
							return false;
						}
					}
					else{
						alert("must use % symbol after tax amount");
					}
				}
			}
			else{
				alert("Don't use % symbol in first place");
			}
		}
		}

		else{
			alert("Must add tax word or add space before tax word");
		}
	} 
}

sale_set_tax();

//read taxes from localStorage

function sale_read_tax(){
	var i;
	for(i=0;i<localStorage.length;i++)
	{
		var all_keys = localStorage.key(i);
		if(all_keys.match("stax_"))
		{
			var key_data = localStorage.getItem(all_keys);
			var read_data = JSON.parse(key_data);
			document.getElementById("sale-taxes-name").innerHTML += "<p style='padding:0;margin:0;'>"+read_data.tax_name+" - "+"<span>"+read_data.tax+"</span>"+"</p><br>";
		}
	}
}

sale_read_tax();

//calculate taxes 

function sale_calculate_taxes(){
	var subtotal_amount = Number(document.getElementById("salesubtotal-amount").innerHTML);
	var taxes_name = document.getElementById("sale-taxes-name");
	var span = taxes_name.getElementsByTagName("SPAN");
	document.getElementById("sale-taxes-amount").innerHTML = "";
	var i;
	for(i=0;i<span.length;i++)
	{
		var num = span[i].innerHTML.replace("%","");
		var cal = (subtotal_amount*num)/100;
		var tofixed = cal.toFixed(2);
		var percentage = "<p class='fa fa-rupee' style='padding:0;margin:0;'> "+tofixed+"</p><br><br>";
		document.getElementById("sale-taxes-amount").innerHTML += percentage;
	}
}

//calculate total

function sale_calculate_total()
{	
	var subtotal_amount = Number(document.getElementById("salesubtotal-amount").innerHTML);
	var taxes_name = document.getElementById("sale-taxes-name").innerHTML;
	if(taxes_name != "")
	{
		var taxes_amount = document.getElementById("sale-taxes-amount");
		var p = taxes_amount.getElementsByTagName("P");
		var i;
		for(i=0;i<p.length;i++)
		{
			subtotal_amount += Number(p[i].innerHTML);
			document.getElementById("sale-total").innerHTML = "<p class='fa fa-rupee' id='salecalculated-total'> "+subtotal_amount.toFixed(2)+"</p>";
		}
		sale_paid();
	}

	else{
		document.getElementById("sale-total").innerHTML = "<p class='fa fa-rupee' id='salecalculated-total'> "+subtotal_amount.toFixed(2)+"</p>";
		sale_paid();
	}
}

//calculate paid and dues

function sale_paid()
{
	var paid = document.getElementById("sale-paid");
	paid.oninput = function(){
		var total = Number(document.getElementById("salecalculated-total").innerHTML);
		var dues = document.getElementById("sale-dues");
		dues.innerHTML = "<p id='salecalculated-dues' class='fa fa-rupee'> "+(total-Number(this.value)).toFixed(2)+"</p>";
	}
}

//sale voucher no

function sale_voucher_no(){
	var voucher_no = document.getElementById("sales-no");
	var i,large_no = 0;
	for(i=0;i<localStorage.length;i++)
	{
		var all_keys = localStorage.key(i);
		if(all_keys.match("sales_voucher"))
		{
			var num = Number(all_keys.replace("sales_voucher_",""));
			if(num > large_no)
			{
				large_no = num;
			}
		}
	}
	voucher_no.innerHTML = large_no+1;
}

sale_voucher_no();

//sales date

function sales_date()
{
	var date = document.getElementById("sales-date");
	var d = new Date();
	var c_date = d.getDate();
	var c_month = d.getMonth()+1;
	var c_year = d.getFullYear();
	date.innerHTML = "<span id='sale-date'>"+c_date+"-"+c_month+"-"+c_year+"</span>";
	var p_date = document.getElementById("sale-date");
	p_date.style.cursor = "pointer";
	p_date.title = "Click to change";
	p_date.onclick = function()
	{
		this.innerHTML = "";
		var input = document.createElement("INPUT");
		input.type = "date";
		date.append(input);
		input.onblur = function(){
			this.remove();
			var s_date = new Date(this.value);
			var final_date = [s_date.getDate(),s_date.getMonth()+1,s_date.getFullYear()];
			p_date.innerHTML = final_date[0]+"-"+final_date[1]+"-"+final_date[2];
		}

		input.onchange = function(){
			this.remove();
			var s_date = new Date(this.value);
			var final_date = [s_date.getDate(),s_date.getMonth()+1,s_date.getFullYear()];
			p_date.innerHTML = final_date[0]+"-"+final_date[1]+"-"+final_date[2];
		}
	}
}
sales_date();

//sales current balance

function sale_current_balance()
{
	var i,balance = 0;
	for(i=0;i<localStorage.length;i++)
	{
		var all_keys = localStorage.key(i);
		if(all_keys.match("sales_voucher"))
		{
			var key_data = localStorage.getItem(all_keys);
			var data = JSON.parse(key_data);
			balance += Number(data.total);
		}

	}
	document.getElementById("sales-balance").innerHTML = balance+" Dr";
}

sale_current_balance();

//storing sales voucher

function sale_store_voucher()
{
	var i,store_item = [],store_qty = [],store_rate = [],store_per = [],store_amount = [],store_tax = [];
	var voucher_no = document.getElementById("sales-no").innerHTML;
	var voucher_date = document.getElementById("sales-date").innerHTML;
	var ac_name = document.getElementById("sales-input").value;
	var item_input = document.getElementsByClassName("saleitem-input");
	for(i=0;i<item_input.length;i++)
	{
		store_item[i] = item_input[i].value;
	}

	var qty_input = document.getElementsByClassName("saleqty-input");
	for(i=0;i<qty_input.length;i++)
	{
		store_qty[i] = qty_input[i].value;
	}

	var rate_input = document.getElementsByClassName("salerate-input");
	for(i=0;i<rate_input.length;i++)
	{
		store_rate[i] = rate_input[i].value;
	}

	var per_input = document.getElementsByClassName("saleper-input");
	for(i=0;i<per_input.length;i++)
	{
		store_per[i] = per_input[i].value;
	}

	var amount_input = document.getElementsByClassName("saleamount-input");
	for(i=0;i<amount_input.length;i++)
	{
		store_amount[i] = amount_input[i].value;
	}

	var cus_name = document.getElementById("cus-name").value;
	var cus_mob = document.getElementById("cus-number").value;
	var cus_address = document.getElementById("cus-address").value;
	var subtotal = document.getElementById("salesubtotal-amount").innerHTML;
	var taxes_amount = document.getElementById("sale-taxes-amount");
	var taxes = taxes_amount.getElementsByTagName("P");

	for(i=0;i<taxes.length;i++)
	{
		store_tax[i] = taxes[i].innerHTML;
	}

	var total = document.getElementById("salecalculated-total").innerHTML;
	var paid = document.getElementById("sale-paid").value;
	var dues = document.getElementById("salecalculated-dues").innerHTML;

	var sales_details = {
		voucher_no : voucher_no,
		voucher_date : voucher_date,
		ac_name :ac_name,
		store_item : store_item,
		store_qty : store_qty,
		store_rate : store_rate,
		store_per : store_per,
		store_amount : store_amount,
		cus_name : cus_name,
		cus_mob : cus_mob,
		cus_address : cus_address,
		subtotal : subtotal,
		store_tax : store_tax,
		total : total,
		paid : paid,
		dues : dues
	}
	var sales_data = JSON.stringify(sales_details);
	localStorage.setItem("sales_voucher_"+voucher_no,sales_data);
	if(localStorage.getItem("sales_voucher_"+voucher_no) != null)
	{
		var notice = document.getElementById("sale-success-notice");
		notice.innerHTML = "Saving please wait...";
		setTimeout(function(){
			notice.innerHTML = "<span style='color:red;font-family:Ubuntu;font-size:20px;font-width:bold;'>Click here to print voucher || ctrl+r to create new voucher</span>"
		},1000);
	}

	else{
		alert("Voucher not saved press ok to create again");
		window.location = location.href;
	}
}

function sale_store_now(){
	document.getElementById("sale-store").onclick = function(){
		if(document.getElementById("salesubtotal-amount") != null)
		{
			if(document.getElementById("sale-paid").value != "")
			{
				sale_store_voucher();
			}

			else{
				alert("paid is empty");
				document.getElementById("sale-paid").focus();
				return false;
			}
		}

		else{
			alert("no item bought yet !");
			return false;
		}	
	}
}

sale_store_now();

//search voucher

function sale_search_voucher()
{
	var search = document.getElementById("sale-search");
	search.onkeyup = function(event){
		if(event.keyCode == 13)
		{
			if(this.value != "")
			{
				var voucher = localStorage.getItem("sales_voucher_"+this.value);
				if(voucher != null)
				{
					sale_delete_voucher();
					var data = JSON.parse(voucher);
					document.getElementById("sales-no").innerHTML = data.voucher_no;
					document.getElementById("sales-date").innerHTML = data.voucher_date;
					document.getElementById("sales-input").value = data.ac_name;
					document.getElementById("sales-hint").style.display = "none";
					var i;
					for(i=0;i<data.store_item.length;i++)
					{
						sale_add_item();
					}

					var item_input = document.getElementsByClassName("saleitem-input");
					var qty_input = document.getElementsByClassName("saleqty-input");
					var rate_input = document.getElementsByClassName("salerate-input");
					var per_input = document.getElementsByClassName("saleper-input");
					var amount_input = document.getElementsByClassName("saleamount-input");
					for(i=0;i<item_input.length;i++)
					{
						item_input[i].value = data.store_item[i];
						qty_input[i].value = data.store_qty[i];
						qty_input[i].disabled = false;
						rate_input[i].value = data.store_rate[i];
						rate_input[i].disabled = false;
						per_input[i].value = data.store_per[i];
						amount_input[i].value = data.store_amount[i];
						amount_input[i].disabled = false;

					}

					document.getElementById("cus-name").value = data.cus_name;
					document.getElementById("cus-name").disabled = false;
					document.getElementById("cus-number").value = data.cus_mob;
					document.getElementById("cus-number").disabled = false;
					document.getElementById("cus-address").value = data.cus_address;
					document.getElementById("cus-address").disabled = false;
					document.getElementById("sales-add-item").disabled = false;
					var subtotal_td = document.getElementById("sale-subtotal");
					subtotal_td.innerHTML = "";
					var subtotal_p = document.createElement("P");
					subtotal_p.append(document.createTextNode(data.subtotal));
					subtotal_p.id = "salesubtotal-amount";
					subtotal_p.className = "fa fa-rupee";
					subtotal_td.append(subtotal_p);
					document.getElementById("sale-taxes-amount").innerHTML = "";
					for(i=0;i<data.store_tax.length;i++)
					{
						var taxes_amount = document.getElementById("sale-taxes-amount");
						var taxes_p = document.createElement("P");
						var taxes_br = document.createElement("BR");
						taxes_p.append(document.createTextNode(" "+data.store_tax[i]));
						taxes_p.className = "fa fa-rupee";
						taxes_p.style.float = "left";
						taxes_p.style.clear = "left";
						taxes_p.style.margin = "2px";
						taxes_p.style.padding = "0";
						taxes_p.innerHTML += "<br><br>";
						//taxes_p.append(document.createElement("BR"));
						
						taxes_amount.append(taxes_p);
					}

					var total = document.getElementById("sale-total");
					total.innerHTML = "";
					var total_p = document.createElement("P");
					total_p.append(document.createTextNode(data.total));
					total_p.id = "salecalculated-total";
					total_p.className = "fa fa-rupee";
					total.append(total_p);

					document.getElementById("sale-paid").value = data.paid;

					var dues = document.getElementById("sale-dues");
					dues.innerHTML = "";
					var dues_p = document.createElement("P");
					dues_p.append(document.createTextNode(data.dues));
					dues_p.id = "salecalculated-dues";
					dues_p.className = "fa fa-rupee";
					dues.append(dues_p);
				}

				else{
					alert("No voucher found !");
				}
			}

			else{
				alert("Enter voucher number");
			}
		}
	}
}

sale_search_voucher();

//delete voucher

function sale_delete_voucher()
{
	var del = document.getElementById("sale-voucher-delete");
	del.onclick = function(){
		var choice = window.confirm("Do you want to delete voucher");
		if(choice == true)
		{
			localStorage.removeItem("sales_voucher_"+document.getElementById("sale-search").value);
			window.location = location.href;
		}
	}
}