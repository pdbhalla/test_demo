// JavaScript Document
// dynamic navbar toggler
$(document).ready(function(){
	
	$("#nav-icon").click(function(){
	 $("#mobile-menu").collapse('toggle');
	  $("#mobile-menu").addClass("animated ZoomIn");	
		
	});
	
});

//typing animation


$(document).ready(function(){
	
var string="BE STYLISH";
var i;
i=0;
if(i<string.length)
	{
		setInterval(function(){
			
			document.querySelector(".add-header").innerHTML += string.charAt(i);
			i++;
		},100);
		
		
	}
});

//search box collapse

$(document).ready(function(){
	$("#search-icon").click(function(){
	$("#search-box").collapse('toggle');	
		
	});
	$("#search-box").on('show.bs.collapse',function(){
		$("#header-slider h1").animate({marginTop:"50px"});
	});
	
	$("#search-box").on('hide.bs.collapse',function(){
		$("#header-slider h1").animate({marginTop:"0px"});
	});
	
	
	
	
});


//client slider



$(document).ready(function(){
 $("#next-client").click(function(){
	$("#client-slider").carousel('next'); 
	 
 });	
$("#prev-client").click(function(){
	$("#client-slider").carousel('prev'); 
	 
 });		
	
});


//num animate

$(window).scroll(function(){
	if(sessionStorage.getItem("user_scroll") == null){
	

	var value=$("#people-say").attr('class');
	if(value.indexOf("animated") != -1)
		{
			animate();
			sessionStorage.setItem("user_scroll", "yes");
		}
	}
});

function animate(){
$(document).ready(function(){
	var num=0;
	var repeat=setInterval(function(){
		num+=1;
		$("#num-one").html(num+"+");
		if(num == 500)
			{
				clearInterval(repeat);
			}
		
	},100);
	
	
	
	
});

$(document).ready(function(){
	var num=0;
	var repeat=setInterval(function(){
		num+=1;
		$("#num-two").html(num+"+");
		if(num == 700)
			{
				clearInterval(repeat);
			}
		
	},100);
	
	
	
	
});


$(document).ready(function(){
	var num=0;
	var repeat=setInterval(function(){
		num+=1;
		$("#num-three").html(num+"+");
		if(num == 300)
			{
				clearInterval(repeat);
			}
		
	},100);
	
	
	
	
});


$(document).ready(function(){
	var num=0;
	var repeat=setInterval(function(){
		num+=1;
		$("#num-four").html(num+"+");
		if(num == 100)
			{
				clearInterval(repeat);
			}
		
	},100);
	
	
	
	
});

}

