// JavaScript Document
$(document).ready(function(){
	 var class_name=sessionStorage.getItem("student_class");
	 alert(class_name);
	
})