// JavaScript Document
$(document).ready(function(){
	var class_name=sessionStorage.getItem("student_class");
	alert(class_name);
	var db_name=sessionStorage.getItem("db_name");
	var database=window.indexedDB.open(db_name);
	database.onsuccess=function(){
		var idb=this.result;
		var permission=idb.transaction("admission","readwrite");
		var access=permission.objectStore("admission");
		var keys_data=access.getAllKeys();
		keys_data.onsuccess=function(){
			var keys_array=this.result;
			var i;
			for(i=0; i<keys_array.length; i++)
				{
				 var check_data=access.get(keys_array[i]);
					check_data.onsuccess=function(){
						var data=this.result;
					if(data.class == class_name)
						{
							var tr=document.createElement("TR");
							var pic_td=document.createElement("TD");
							var image=new Image();
							image.src=data.pic;
							image.width="80";
							image.height="80";
							pic_td.append(image);
							var sname_td=document.createElement("TD");
							sname_td.innerHTML=data.s_name;
							sname_td.style.verticalAlign="middle";
							var fname_td=document.createElement("TD");
							fname_td.innerHTML=data.f_name;
							fname_td.style.verticalAlign="middle";
							var mname_td=document.createElement("TD");
							mname_td.innerHTML=data.m_name;
							mname_td.style.verticalAlign="middle";
							var dob_td=document.createElement("TD");
							dob_td.innerHTML=data.dob;
							dob_td.style.verticalAlign="middle";
							var doa_td=document.createElement("TD");
							doa_td.innerHTML=data.doa;
							doa_td.style.verticalAlign="middle";
							var mo_td=document.createElement("TD");
							mo_td.innerHTML=data.mobile_one;
							mo_td.style.verticalAlign="middle";
							var mt_td=document.createElement("TD");
							mt_td.innerHTML=data.mobile_two;
							mt_td.style.verticalAlign="middle";
							var add_td=document.createElement("TD");
							add_td.innerHTML=data.address;
							add_td.style.verticalAlign="middle";
							tr.append(pic_td);
							tr.append(sname_td);
							tr.append(fname_td);
							tr.append(mname_td);
							tr.append(dob_td);
							tr.append(doa_td);
							tr.append(mo_td);
							tr.append(mt_td);
							tr.append(add_td);
							$(".student-table").append(tr);
							
						}
					}
				}
		};
	}
	});


//retrive school_logo
$(document).ready(function(){
	var db_name=sessionStorage.getItem("db_name");
	var database=window.indexedDB.open(db_name);
	database.onsuccess=function(){
		var idb=this.result;
		var permission=idb.transaction("about_school", "readwrite");
		var access=permission.objectStore("about_school");
		var check_data=access.get(db_name);
		check_data.onsuccess=function(){
			var data=this.result;
			console.log(data);
			var image_logo=new Image();
			image_logo.src=data.school_logo;
			image_logo.width="130";
			image_logo.height="100";
			
			var tr=document.getElementById("main");
			var logo_td=document.createElement("TD");
			logo_td.className="logo";
			
			$(".logo").html(image_logo);
			logo_td.append(image_logo);
			tr.append(logo_td);
			
			var s_name_td=document.createElement("TD");
			var school_name="<h1>"+data.school_name+"</h1>";
			
			
			var tagline=data.tag_line;
			s_name_td.innerHTML+=school_name;
			s_name_td.innerHTML+="<br>"+"<h5>"+tagline+"</h5>";
			s_name_td.innerHTML+="<br><p style:padding:0; margin-left:80px;>contact no :"+data.mobile_number+"</p>";
			s_name_td.setAttribute("colspan","8");
			tr.append(s_name_td);
			
			
			//retrive principal signature
			var psign_table = document.getElementById("signature");
			var psign=new Image();
			psign.src=data.principal_signature;
			psign.width="250";
			psign.height="190";
			var psign_td=document.createElement("TD");
			var psign_tr = document.createElement("TR");
			psign_td.className="p-sign";
			psign_td.style.paddingRight="60px";
			$(".p-sign").html(psign);
			psign_td.append(psign);
			psign_td.append("Principal Signature");
			psign_tr.append(psign_td);
		    psign_table.append(psign_tr);
			
			
			//retrive director signature
			var dsign=new Image();
			dsign.src=data.director_signature;
	
			dsign.width="250";
			dsign.height="190";
			var dsign_td=document.createElement("TD");
			dsign_td.className="d-sign";
			dsign_td.style.marginRight="100px";
			$(".d-sign").html(dsign_td);
			dsign_td.append(dsign);
			dsign_td.innerHTML+="<br> <p style='margin-left:50px;'>Director Signature</p>";
			dsign_td.setAttribute("colspan", "8");
			psign_tr.append(dsign_td);
			psign_table.append(psign_tr);
			
			
			
			
		}
		
	}
});




