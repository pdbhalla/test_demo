// JavaScript Document	

        var date=new Date($(".dob").val());
		var dob_day=date.getDate();
		var dob_month=date.getMonth()+1;
		var dob_year=date.getFullYear();
		alert(dob_day+"/"+dob_month+"/"+dob_year);
		var dob=dob_day+"/"+dob_month+"/"+dob_year;
		var c_date=new Date();
		var doa_day=c_date.getDate();
		var doa_month=c_date.getMonth()+1;
		var doa_year=c_date.getFullYear();
		var doa=doa_day+"/"+doa_month+"/"+doa_year;
		alert(doa);
		if(sessionStorage.getItem("upload_pic") != null)
			{
		var admission={
			adm_no:
			s_name:$(".s-name").val(),
			f_name:$(".f-name").val(),
			m_name:$(".m-name").val(),
			dob:dob,
			gender:$(".gender").val(),
			mobile_one:$(".mobile-one").val(),
			mobile_two:$(".mobile-two").val(),
			class:$(".class").val(),
			admit_in:$("admit-in").val(),
			address:$(".address").val(),
			doa:doa,
			pic:sessionStorage.getItem("upload_pic"),
		}
           sessionStorage.removeItem("upload_pic");
		   var db_name=sessionStorage.getItem("db_name");
		   var database=window.indexedDB.open(db_name);
				database.onsuccess=function(){
					var idb=this.result;
					var permission=idb.transaction("admission","readwrite");
					var access=permission.objectStore("admission");
				var check_admission=access.add(admission);
					check_admission.onsuccess=function(){
						var alert="<div class='alert alert-success '><i class='fa fa-close close' data-dismiss='alert'></i><b>Admission success !</b><a href='admission_slip.html'>get admission document</a></div>";
						$(".admit-notice").html(alert);
						adm_no();
					}
					
					check_admission.onerror=function(){
						var alert="<div class='alert alert-warning'><i class='fa fa-close close' data-dismiss='alert'></i><b>Admission Failed !</b></div>";
						$(".admit-notice").html(alert);
						
					}
				}
		
		}
		
		else{
			alert("Please upload student's pic");
		}